const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { dirname } = require('path');

// Create directory if it doesn't exist
function createDirIfNotExists(dir) {
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
}

// Set up storage for profile pictures and certifications
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        let dir;
        if (file.fieldname === 'profilePicture') {
            dir = 'public/uploads/profile-pictures/';
        } else if (file.fieldname === 'certifications') {
            dir = 'public/uploads/certifications/';
        } else {
            dir = 'public/uploads/temp/';
        }
        createDirIfNotExists(dir);
        cb(null, dir);
    },
    filename: function (req, file, cb) {
        // Create a unique filename using timestamp and original name
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        const fieldName = file.fieldname === 'certifications' ? 'cert-' : 'profile-';
        cb(null, fieldName + uniqueSuffix + path.extname(file.originalname));
    }
});

// File filter to allow images and PDFs
const fileFilter = (req, file, cb) => {
    // Allow image files and PDFs
    if (file.mimetype.startsWith('image/') || file.mimetype === 'application/pdf') {
        cb(null, true);
    } else {
        cb(new Error('Only image files and PDF documents are allowed!'), false);
    }
};

// Create multer instance with storage and file filter
const upload = multer({
    storage: storage,
    fileFilter: fileFilter,
    limits: {
        fileSize: 100 * 1024 * 1024 // 100MB
    }
});

// Middleware to handle multiple file uploads
const profileUpload = upload.fields([
    { name: 'profilePicture', maxCount: 1 },
    { name: 'certifications', maxCount: 10 } // Allow up to 10 certification files
]);

module.exports = profileUpload;