const express = require('express');
const { register, login, logout, getProfile, getPublicProfile, getAllAdminProfiles, updateProfile, createAdminUser, forgotPassword, resetPassword, updatePassword } = require('../controllers/auth.controller');
const { authenticateToken } = require('../middlewares/auth.middleware');
const { validateLogin } = require('../middlewares/validate.middleware');
const upload = require('../middlewares/upload.middleware');
const profileUpload = require('../middlewares/profileUpload.middleware');

const router = express.Router();

router.post('/register', register);
router.post('/login', validateLogin, login);
router.post('/logout', authenticateToken, logout);
router.get('/profile', authenticateToken, getProfile);
router.get('/profile/:userId', getPublicProfile); // Public profile endpoint for individual admin access
router.get('/admins/public', getAllAdminProfiles); // Public endpoint to get all admin profiles
router.put('/profile', authenticateToken, profileUpload, updateProfile);
router.post('/admin/create', createAdminUser);
router.post('/forgot-password', forgotPassword);
router.post('/reset-password/:token', resetPassword);
router.put('/update-password', authenticateToken, updatePassword);

module.exports = router;